package cpsc2150.extendedConnectX.controllers;

import cpsc2150.extendedConnectX.models.*;
import cpsc2150.extendedConnectX.views.*;

/**
 * The controller class will handle communication between our View and our Model ({@link IGameBoard})
 * <p>
 * This is where you will write code
 * <p>
 * You will need to include your your {@link BoardPosition} class, {@link IGameBoard} interface
 * and both of the {@link IGameBoard} implementations from Project 4.
 * If your code was correct you will not need to make any changes to your {@link IGameBoard} implementation class.
 *
 * @version 2.0
 */
public class ConnectXController {

    /**
     * <p>
     * The current game that is being played
     * </p>
     */
    private IGameBoard curGame;

    /**
     * <p>
     * The screen that provides our view
     * </p>
     */
    private ConnectXView screen;
    
    /**
     * <p>
     * The number of players for this game. Note that our player tokens are hard coded.
     * </p>
     */
    private int numPlayers;

    /**
     * <p>
     * A character array of player characters
     * </p>
     */
    char[] playerChar = {'X', 'Y', 'Z', 'A', 'B', 'C', 'D', 'E', 'F', 'G'};

    /**
     * <p>
     * Number of times the player has clicked a button. Note this is for cycling through the player characters
     * </p>
     */
    int numClicks;

    /**
     * <p>
     * This creates a controller for running the Extended ConnectX game
     * </p>
     * 
     * @param model
     *      The board implementation
     * @param view
     *      The screen that is shown
     * @param np
     *      The number of players for this game.
     * 
     * @post [ the controller will respond to actions on the view using the model. ]
     */
    public ConnectXController(IGameBoard model, ConnectXView view, int np) {
        this.curGame = model;
        this.screen = view;
        this.numPlayers = np;
        numClicks = 0;
    }

    /**
     * <p>
     * This processes a button click from the view.
     * </p>
     * 
     * @param col 
     *      The column of the activated button
     * 
     * @post [ will allow the player to place a token in the column if it is not full, otherwise it will display an error
     * and allow them to pick again. Will check for a win as well. If a player wins it will allow for them to play another
     * game hitting any button ]
     */
    public void processButtonClick(int col) {
        char curPlayer = playerChar[numClicks % numPlayers];
        int row = 0;

        //Starting a new game if the player clicks a button after winning
        for (int i = 0; i < curGame.getNumColumns(); ++i) {
            if ((curGame.checkForWin(i)) || (curGame.checkTie())) {
                newGame();
                return;
            }
        }
        //Checking if column is full
        if (!curGame.checkIfFree(col)) {
            screen.setMessage("Column is full");
            return;
        }
        //Getting the lowest available row
        for (int i = 0; i < curGame.getNumRows(); ++i) {
            BoardPosition pos = new BoardPosition(i, col);
            if (curGame.whatsAtPos(pos) == ' ') {
                row = i;
                break;
            }
        }
        //Placing token
        screen.setMarker(row, col, curPlayer);
        curGame.placeToken(curPlayer, col);
        ++numClicks;

        screen.setMessage("It is " + playerChar[numClicks % numPlayers] + "s turn. ");

        //checking for win
        if (curGame.checkForWin(col)) {
            screen.setMessage("Player " + curPlayer + " Won!");
            return;
        }

        //checking for Tie
        if (curGame.checkTie()) {
            screen.setMessage("Tie!");
        }
    }

    /**
     * <p>
     * This method will start a new game by returning to the setup screen and controller
     * </p>
     * 
     * @post [ a new game gets started ]
     */
    private void newGame() {
        //close the current screen
        screen.dispose();
        
        //start back at the set up menu
        SetupView screen = new SetupView();
        SetupController controller = new SetupController(screen);
        screen.registerObserver(controller);
    }
}
