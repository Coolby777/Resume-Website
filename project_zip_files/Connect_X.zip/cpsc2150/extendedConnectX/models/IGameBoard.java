package cpsc2150.extendedConnectX.models;

/**
 * @author Colby Kopacz
 * @version 2.0
 *
 * A 2 dimensional board of characters
 * The board allows you to add characters and check if a player has won
 *
 * Initialization ensures:
 *      Each position in board is set to a space " " character
 * Define:
 *      board: S[][] (2 dimensional array of characters)
 *      board: Map<Character, List<BoardPosition>> board
 *          (A map that contains player characters for keys and a list of the players board positions as the values)
 * Constraints:
 *          0 {@code <=} board[] {@code <} sizeOfRow
 *          board[][] {@code <} sizeOfColumn AND 0 <= board[][].size()
 *          AND [The maximum number of keys is 10]
 */
public interface IGameBoard {
    /**
     * This function will check if the column can accept another token
     *
     * @param c represents the column we are checking
     * @return true iff column c has any blank spaces left to fill
     *         false iff column c does not have any blank spaces to fill
     *
     * @pre
     * c {@code >=} 0 AND MIN_SIZE {@code <} MAX_SIZE
     * @post
     * c = #c AND board = #board AND checkIfFree iff myBoard[MAX_RC] = ' ' AND myBoard = #myBoard
     *
     */
    public default boolean checkIfFree(int c) {
        int count;
        BoardPosition pos;
        for (int i = 0; i < getNumRows(); ++i) {
            pos = new BoardPosition(i, c);
            if (whatsAtPos(pos) == ' ') {
                return true;
            }
        }
        return false;
    }

    /**
     * This function will place the character p in the lowest available row in column c.
     *
     * @param p represents the character that the player is placing into the board
     * @param c represents the column that is being checked
     *
     * @pre
     * c {@code >=} MIN_SIZE AND c {@code <} MAX_SIZE
     * @post
     * [The token is placed in the lowest available row in column c]
     * AND c = #c AND p = #p AND [board = #board, except the lowest available position]
     */
    public void placeToken(char p, int c);

    /**
     * This function will check to see if the last token placed in
     * column c resulted in the player winning the game.
     *
     * @param c column we are checking
     * @return true iff c is the 5th token placed in a row(of the same tokens)
     *         false iff c is not the last token placed resulting in a win
     *
     * @pre
     * c {@code >=} MIN_SIZE AND c {@code <} MAX_SIZE
     * @post
     * c = #c AND board = #board
     */
    public default boolean checkForWin(int c) {
        char p = '?';
        BoardPosition pos = null;

        for (int i = getNumRows() - 1; i >= 0; --i) {
            pos = new BoardPosition(i, c);
            if (whatsAtPos(pos) != ' ') {
                p = whatsAtPos(pos);
                break;
            }
        }

        if (checkHorizWin(pos, p) || checkVertWin(pos, p) || checkDiagWin(pos, p)) {return true;}
        return false;
    }

    /**
     * This function will check to see if the game has resulted in a tie.
     *
     * @return true iff there are no free board positions remaining
     *         false iff there are still bree board positions
     * @pre
     * No pre
     * @post
     * [boolean returned represents whether there are enough spaces to play on] AND c = #c AND board = #board
     */
    public default boolean checkTie() {
        for (int i = 0; i < getNumColumns(); ++i) {
            BoardPosition pos = new BoardPosition(getNumRows() - 1, i);
            if (whatsAtPos(pos) == ' ') {
                return false;
            }
        }
        return true;
    }

    /**
     * This function checks to see if the last token placed resulted in 5 in a row horizontally
     *
     * @param pos represents the row and column placement
     * @param p represents the players character that is being placed
     * @return true iff the last token placed resulted in 5 in a row horizontally
     *         false iff the last token placed did not result in 5 in a row horizontally
     *
     * @pre
     * [pos holds 2 numbers representing the row and column]
     *     AND pos.getColumn {@code >=} MIN_SIZE AND pos.getColumn {@code <=} MAX_SIZE
     *     AND pos.getRow {@code >=} MIN_SIZE AND pos.getRow {@code <=} MAX_SIZE
     * @post
     * pos = #pos AND p = #p AND board = #board
     */
    public default boolean checkHorizWin(BoardPosition pos, char p) {
        int count = 0;
        BoardPosition temp = null;
        if (pos.getColumn() != (getNumColumns() - 1)) {
            for (int i = pos.getColumn(); i < getNumColumns(); ++i) {
                temp = new BoardPosition(pos.getRow(), i);
                if (whatsAtPos(temp) == p) {
                    ++count;
                } else {break;}
            }
        }
        else {++count;}

        if (pos.getColumn() != 0) {
            for (int i = (pos.getColumn() - 1); i >= 0; --i) {
                temp = new BoardPosition(pos.getRow(), i);
                if (whatsAtPos(temp) == p) {
                    ++count;
                } else {break;}
            }
        }

        if (count >= getNumToWin()) {return true;}
        return false;
    }

    /**
     * This function checks to see if the last token placed resulted in 5 in a row vertically
     *
     * @param pos represents the row and column placement
     * @param p represents the players character that is being placed
     * @return true iff the last token placed resulted in 5 in a row horizontally
     *         false iff the last token placed did not result in 5 in a row horizontally
     *
     * @pre
     * [pos holds 2 numbers representing the row and column]
     *     AND pos.getColumn {@code >=} MIN_SIZE AND pos.getColumn {@code <=} MAX_SIZE
     *     AND pos.getRow {@code >=} MIN_SIZE AND pos.getRow {@code <=} MAX_SIZE
     * @post
     * pos = #pos AND p = #p AND board = #board
     */
    public default boolean checkVertWin(BoardPosition pos, char p) {
        int count = 0;
        BoardPosition temp = null;

        if (pos.getRow() != (getNumRows() - 1)) {
            for (int i = pos.getRow(); i < getNumRows(); ++i) {
                temp = new BoardPosition(i, pos.getColumn());
                if (whatsAtPos(temp) == p) {
                    ++count;
                } else {break;}
            }
        }
        else {++count;}

        if (pos.getRow() != 0) {
            for (int i = (pos.getRow() - 1); i >= 0; --i) {
                temp = new BoardPosition(i, pos.getColumn());
                if (whatsAtPos(temp) == p) {
                    ++count;
                } else {break;}
            }
        }

        if (count >= getNumToWin()) {return true;}
        return false;
    }

    /**
     * This function checks to see if the last token placed resulted in 5 in a row diagonally
     *
     * @param pos represents the row and column placement
     * @param p represents the players character that is being placed
     * @return true iff the last token placed resulted in 5 in a row diagonally
     *         false  iff the last token placed did not result in 5 in a row diagonally
     *
     * @pre
     * [pos holds 2 numbers representing the row and column]
     *     AND pos.getColumn {@code >=} MIN_SIZE AND pos.getColumn {@code <=} MAX_SIZE
     *     AND pos.getRow {@code >=} MIN_SIZE AND pos.getRow {@code <=} MAX_SIZE
     * @post
     * pos = #pos AND p = #p AND board = #board
     */
    public default boolean checkDiagWin(BoardPosition pos, char p) {
        int countRight = 0, countLeft = 0, r = pos.getRow(), c = pos.getColumn();
        BoardPosition temp = null;

        //checking right diagonal
        while ((r < getNumRows()) && (c < getNumColumns())) {
            temp = new BoardPosition(r, c);
            if (whatsAtPos(temp) == p) {
                ++countRight;
            } else {break;}
            ++r;
            ++c;
        }

        r = pos.getRow() - 1;
        c = pos.getColumn() - 1;

        while ((r >= 0) && (c >= 0)) {
            temp = new BoardPosition(r, c);
            if (whatsAtPos(temp) == p) {
                ++countRight;
            } else {break;}
            --r;
            --c;
        }
        if (countRight >= getNumToWin()) {return true;}

        //checking left diagonal
        r = pos.getRow();
        c = pos.getColumn();
        while ((r < getNumRows()) && (c >= 0)) {
            temp = new BoardPosition(r, c);
            if (whatsAtPos(temp) == p) {
                ++countLeft;
            } else {break;}
            ++r;
            --c;
        }

        r = pos.getRow() - 1;
        c = pos.getColumn() + 1;

        while ((r >= 0) && (c < getNumColumns())) {
            temp = new BoardPosition(r, c);
            if (whatsAtPos(temp) == p) {
                ++countLeft;
            } else {break;}
            --r;
            ++c;
        }
        if (countLeft >= getNumToWin()) {return true;}

        return false;
    }

    /**
     * This function returns what is in the cpsc2150.extendedConnectX.models.GameBoard/GameBoardMem at position pos
     *
     * @param pos represents the row and column placement
     * @return The character that is in position pos
     *
     * @pre
     * [pos holds 2 numbers representing the row and column]
     *     AND pos row and col {@code <=} MAX_SIZE]  AND pos row and col {@code >=} MIN_SIZE]
     * @post
     * [returns the character that is in position pos] AND [pos row and col {@code >} 0]
     * AND pos = #pos AND board = #board
     */
    public char whatsAtPos(BoardPosition pos);

    /**
     * This function will return true if the player is at pos
     *
     * @param pos represents the row and column placement
     * @param player character representation of the player
     * @return true iff the players character matches position pos
     *         false iff the players character does not match position pos
     *
     * @pre
     * [pos holds 2 numbers representing the row and column]
     * @post
     * [myChar represents the character that is in position pos] AND pos = #pos AND board = #board
     */
    public default boolean isPlayerAtPos(BoardPosition pos, char player) {
        BoardPosition temp = new BoardPosition(pos.getRow(), pos.getColumn());
        if (whatsAtPos(temp) == player) {
            return true;
        }
        return false;
    }

    /**
     * Returns the number of rows in the GameBoard
     *
     * @return Number of rows in the GameBoard
     *
     * @pre
     * 'none'
     * @post
     * #numRows = numRows AND numRows {@code >=} MIN_SIZE AND numRows {@code <} MAX_SIZE
     */
    public int getNumRows();

    /**
     * Returns the number of columns in the GameBoard
     *
     * @return Number of columns in the GameBoard
     *
     * @pre
     * 'none'
     * @post
     * #numColumns = numColumns AND numColumns {@code >=} MIN_SIZE AND numColumns {@code <=} MAX_SIZE
     */
    public int getNumColumns();

    /**
     * Returns the number of tokens in a row needed to win the game
     *
     * @return Number of tokens in a row needed to win the game
     *
     * @pre
     * 'none'
     * @post
     * [numWin represents the number of tokens needed to win]
     * AND numForWin {@code >=} MIN_SIZE AND numForWin {@code <=} MAX_SIZE
     * AND #numForWin = numForWin
     */
    public int getNumToWin();

}
