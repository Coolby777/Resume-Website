package cpsc2150.extendedConnectX.models;

/**
 * This class will be used to implement the faster board manipulation functionality using
 * an array to store and keep track of each slot on the board.
 *
 * @author Colby Kopacz
 * @version 2.0
 *
 * @invariant numColumns = [number of columns] AND numColumns >= MIN_SIZE AND numColumns <= MAX_SIZE
 *            numRows = [number of rows] AND numRows >= MIN_SIZE AND numRows <= MAX_SIZE
 *            numForWin = [number of tokens in a row needed for player to win]
 *                AND numForWin >= MIN_TO_WIN AND numForWin <= MAX_SIZE
 *            board[][] = [array of board positions with no "gaps" between non-space tokens] AND
 *                board[] {@code <}  numRows AND 0 {@code <=} board[].size()
 *                board[][] {@code <} numColumns AND 0 {@code <=} board[][].size()
 *
 * @correspondences
 *            numRows = [number of the Columns in board]
 *            numColumns = [number of Rows in board]
 *            self = board[0...numRows - 1][0...numColumns - 1], Two Dimensional array of characters
 *                (numRows)  (numColumns) that is initialized full of spaces that are later filled with
 *                player characters
 */

public class GameBoard extends AbsGameBoard implements IGameBoard {

    private int numRows;
    private int numColumns;
    private int numForWin;
    private char[][] board;

    /**
     * Initialized a standard cpsc2150.extendedConnectX.models.GameBoard class object and filling board with spaces
     *
     * @pre 'r' represents the height of the board
     * @pre 'c' represents the width of the board
     * @pre 'w' represents the minimum number of tokens in a row necessary to win
     *
     * @pre
     * r {@code >=} MIN_SIZE AND r {@code <=} MAX_SIZE
     * AND c {@code >=} MIN_SIZE AND c {@code <=} MAX_SIZE
     * AND w {@code >=} MIN_TO_WIN AND w {@code <=} MAX_SIZE AND w {@code <=} r AND w {@code <=} c
     * @post
     * [Default class object is initialized] AND [board array is filled with spaces]
     * AND numRows = r
     * AND numColumns = c
     * AND numForWin = w
     */
    public GameBoard (int r, int c, int w) {
        numRows = r;
        numColumns = c;
        numForWin = w;
        board = new char[getNumRows()][getNumColumns()];

        for (int x = 0; x < getNumRows(); ++x) {
            for (int y = 0; y < getNumColumns(); ++y) {
                board[x][y] = ' ';
            }
        }
    }

    /**
     * contracts in interface
     */
    public void placeToken(char p, int c) {
        BoardPosition bp;
        for (int i = 0; i < getNumRows(); ++i) {
            bp = new BoardPosition(i, c);
            if (whatsAtPos(bp) == ' ') {
                board[i][c] = p;
                return;
            }
        }
    }

    /**
     * contracts in interface
     */
    public char whatsAtPos(BoardPosition pos) {
        return board[pos.getRow()][pos.getColumn()];
    }

    /**
     * contracts in interface
     */
    public int getNumRows() {return numRows;}

    /**
     * contracts in interface
     */
    public int getNumColumns() {
        return numColumns;
    }

    /**
     * contracts in interface
     */
    public int getNumToWin() {return numForWin; }
}
