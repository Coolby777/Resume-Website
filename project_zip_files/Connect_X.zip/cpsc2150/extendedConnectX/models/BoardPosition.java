package cpsc2150.extendedConnectX.models;

/**
 * This class will be used to keep track of an individual cell for a board
 *
 * @author Colby Kopacz
 * @version 2.0
 *
 * @invariant column = [represents the current instance of the column] AND column {@code >=} 0
 *            row = [represents the current instance of the row] AND row {@code >=} 0
 *
 * @correspondense
 *            column = [integer representation of current instance of the column]
 *  *         row = [integer representation of current instance of the row]
 */
public class BoardPosition {
    private int column;
    private int row;


    /**
     * Initialized row and column to their respective passed in values.
     *
     * @param 'row' represents the vertical position of the board
     * @param 'column' represents the horizontal position of the board
     *
     * @pre
     * r {@code >} 0 AND r {@code <} 10 AND c > 0 AND c {@code <} 8
     * @post
     * row = r AND column = c
     */
    public BoardPosition (int r, int c) {
        row = r;
        column = c;
    }

    /**
     * Retrieves the current vertical position of the board
     *
     * @param 'None'
     * @return The vertical position of the board
     *
     * @pre
     * No pre
     * @post
     * row = #row
     */
    public int getRow(){
        return row;
    }

    /**
     * Retrieves the current horizontal position of the board
     *
     * @param 'None'
     * @return The horizontal position of the board.
     *
     * @pre
     * No pre
     * @post
     * column = #column
     */
    public int getColumn() {
        return column;
    }

    /**
     * This method compares a cpsc2150.extendedConnectX.models.BoardPosition obj with an Object o to determine
     * if they have the same row and column
     *
     * @param 'r' represents the vertical position of the board
     * @param 'c' represents the horizontal position of the board
     * @return true iff [row is equal to column]
     *         false iff [row is not equal to column]
     *
     * @pre
     * r {@code >} 0 AND r {@code <} 10 AND c {@code >} 0 AND c {@code <} 8
     * @post
     * [o value does not change]
     */
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }

        if (!(o instanceof BoardPosition)) {
            return false;
        }

        BoardPosition c = (BoardPosition) o;

        if ((Integer.compare(row, c.row) == 0) && (Integer.compare(column, c.column) == 0)) {
            return true;
        }
        return false;
    }


    /**
     * Arranges the passed in values to be in the format "<row>,<column>"
     *
     * @param 'None'
     * @return A string representation of the passed in values in the form "<row>,<column>"
     *
     * @pre
     * No pre
     * @post
     * [currPos represents the passed in values similar to "<row>,<column>"]
     */
    @Override
    public String toString() {
        String placement = getRow() + "," + getColumn();
        return placement;
    }

}
