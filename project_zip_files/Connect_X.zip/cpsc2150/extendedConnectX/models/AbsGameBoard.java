package cpsc2150.extendedConnectX.models;

public abstract class AbsGameBoard implements IGameBoard {

    /**
     * @param 'none'
     * @return str [A string representation of the current instance of the game board]
     *
     * @post iff board is empty str will print spaces where tokens will be
     *       iff board is not empty str will be updated to include the tokens placed
     *       [str represents the current instance of the game board]
     */
    @Override
    public String toString() {
        BoardPosition pos;
        String str = "|";
        for (int i = 0; i < getNumColumns(); ++i) {
            if (i < 10) { str += " " + i + "|"; }
            else { str += i + "|";}
        }
        str += "\n";

        for (int y = getNumRows() - 1; y >= 0; --y) {
            str += "|";
            for (int x = 0; x < getNumColumns(); ++x) {
                pos = new BoardPosition(y, x);
                str += whatsAtPos(pos);
                str += " |";
            }
            str += "\n";
        }

        return str;
    }
}
