package cpsc2150.extendedConnectX.models;
import java.util.*;

/**
 * This class will be used to implement the memory efficient board manipulation functionality using
 * a Map to store the players board positions.
 *
 * @author Colby Kopacz
 * @version 2.0
 *
 * @invariant numColumns = [number of columns] AND numColumns >= MIN_SIZE AND numColumns <= MAX_SIZE
 *            numRows = [number of rows] AND numRows >= MIN_SIZE AND numRows <= MAX_SIZE
 *            numForWin = [number of tokens in a row needed for player to win]
 *                AND numForWin >= MIN_TO_WIN AND numForWin <= MAX_SIZE
 *            Map<Character, List<BoardPosition>> board
 *                = [map of board positions with player characters for keys and a vector of BoardPosition objects
 *                as values] AND [The maximum number of keys is 10]
 *
 * @correspondences
 *            numRows = [number of the Columns in board]
 *            numColumns = [number of Rows in board]
 *            numForWin = [number of tokens in a row needed for player to win]
 *            self = Map<Character, List<BoardPosition>> board, A map of player characters for keys with
 *                a vector of BoardPosition objects which hold the all positions on the board that the key player holds
 */
public class GameBoardMem extends AbsGameBoard implements IGameBoard {
    private int numRows;
    private int numColumns;
    private int numForWin;
    private Map<Character, List<BoardPosition>> board = new HashMap<Character, List<BoardPosition>>();

    /**
     * Initialized a standard cpsc2150.extendedConnectX.models.GameBoard class object and filling board with spaces
     *
     * @param 'r' represents the height of the board
     * @param 'c' represents the width of the board
     * @param 'w' represents the minimum number of tokens in a row necessary to win
     *
     * @pre
     * r {@code >=} MIN_SIZE AND r {@code <=} MAX_SIZE
     * AND c {@code >=} MIN_SIZE AND c {@code <=} MAX_SIZE
     * AND w {@code >=} MIN_TO_WIN AND w {@code <=} MAX_SIZE AND w {@code <=} r AND w {@code <=} c
     * @post
     * numRows = r
     * AND numColumns = c
     * AND numForWin = w
     */
    public GameBoardMem(int r, int c, int w) {
        numRows = r;
        numColumns = c;
        numForWin = w;
    }

    /**
     * contracts in interface
     */
    public char whatsAtPos(BoardPosition pos) {
        for (Map.Entry<Character, List<BoardPosition>> playChar : board.entrySet()) {
            for (int i = 0; i < playChar.getValue().size(); ++i) {
                if (playChar.getValue().get(i).equals(pos)) {
                    return playChar.getKey();
                }
            }
        }
        return ' ';
    }

    /**
     * contracts in interface
     */
    public void placeToken(char p, int c) {
        BoardPosition pos;

        for (int i = 0; i < 100; ++i) {
            pos = new BoardPosition(i, c);
            if (whatsAtPos(pos) == ' ') {
                board.putIfAbsent(p, new ArrayList<>());
                board.get(p).add(pos);
                return;
            }
        }
    }

    /**
     * contracts in interface
     */
    public int getNumRows() { return numRows; }

    /**
     * contracts in interface
     */
    public int getNumColumns() {
        return numColumns;
    }

    /**
     * contracts in interface
     */
    public int getNumToWin() { return numForWin; }

    @Override
    public boolean isPlayerAtPos(BoardPosition pos, char player) {
        BoardPosition temp = new BoardPosition(pos.getRow(), pos.getColumn());
        if (whatsAtPos(temp) == player) {
            return true;
        }
        return false;
    }
}
