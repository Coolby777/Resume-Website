/*
  Colby Kopacz
  CPSC 1070
  C82946549
  09/23/2022

                                                                    Project Plinko  
  
  The following is a program that plays the game Plinko where 
  a user is given a random chance to earn a variety of chances 
  to gamble at an opportunity to earn up to $1,000 
 */


#include <iostream>   //gives us cin/cout
#include <iomanip>    //gives us setprecision which adjusts the output of decimal values
#include <cstdlib>    //gives us rand/srand which generates a random number seed
#include <time.h>     //allows us to use time to generate a new seed
#include <cctype>     //allows functions that check user input

using namespace std;


//PROTOTYPES
//---------------------------------------

void runGame();
char runMenu(int , int);
int bidOnPrizes(void);
int playPlinko(char[12][17], int);
int puckDirection (int, int);
void displayBoard(char[12][17]);
void resetBoard(char[12][17]);

//---------------------------------------
//This method simply runs the game

int main() {
  runGame();
} //main bracket

//--------------------------------------------------------------------------------------------------
//This method will read the users input and call the respective methods that goes with their command

void runGame()  {             //will launch the game
  int numChips = 1;           //number of chips the user has
  int userBid = 0;            //calls the bidOnPrizes method
  int slot = 100;             //players choice slot
  int totWinnings = 0;        //total Winnings
  int currWinnings = 0;       //Winnings earned from current game
  bool hasPlayed = false;     //becomes true when the user has already chosen option 1
  bool quitGame = false;      //breaks out of the while loop when true
  const int row = 12;         //number of rows
  const int column = 17;      //number of columns
  

  //Initializing the PlinkoBoard
  //------------------------------
  char plinkoBoard[row][column];
  resetBoard(plinkoBoard);    
  //-----------------------------

  cout << "Welcome to the CPSC 1070 Plinko!!!" << endl;
  
  do {
    char choice = runMenu(numChips, totWinnings);
    
    switch (choice) {      
    case '1':          //bid on items to earn chips
      if (hasPlayed == true) {                // checking if the player has bid already
	
	cout << "You've already bid on prizes!" << endl;
      }  //if bracket
      else {
	userBid = bidOnPrizes();
	numChips += userBid;
	cout << "You have won " << userBid << " chips!" << endl;     //calling bidOnPrizes      [numChips is added in the method]
	hasPlayed = true;
      }  //else bracket
      break;
    case ('2'):          //play PLINKO!
      if (numChips > 0) { //if you have chips
	resetBoard(plinkoBoard);
	bool valid = false;
	while (valid == false) {   //validating user slot choice
	  cout << "Which slot do you want to drop your puck down (1-9)?: ";
	  cin >> slot;
	  
	  if ((slot >= 1) && (slot <= 9)) { //valid slot input
	    valid = true;
	    --numChips;
	    currWinnings = playPlinko(plinkoBoard, slot);

	    cout << "You have won $" << currWinnings << "!" << endl;
	    totWinnings += currWinnings;
	  }
	  else { //invalid slot input
	    cout << "Invalid Input. Please try again." << endl;
	  }
	}
	
      }
      else { //if your out of chips
	cout << "Sorry, you don't have any more chips!" << endl;
      }
      
      break;
    case '3':           //print out the current board                                                                   
      displayBoard(plinkoBoard);
      
      break;
    case 'q':          //quit                                                                                          
      resetBoard(plinkoBoard);
      quitGame = true;
      
      break;
    case 'Q':
      resetBoard(plinkoBoard);
      quitGame = true;
      
      break;
    default:        //checking for invalid input                                                                          
      cout << "There must have been an issue with the runMenu" << endl;
    } //switch bracket                                                                                                       
    
  }  while(quitGame != true);  //do while loop bracket
  
} //rungame bracket

//-----------------------------------------------------------------------------------------------  
//Requests users choice and calls to the respective functions that coincide with the users choice

char runMenu(int chips, int winnings) {
  char userChoice = '0';
  
  cout << endl << "---- CPSC 1070 Plinko Menu ----" << endl << endl;
  cout << " You have " << chips << " Plinko chips to use" << endl;
  cout << " Total Winnings $" << setprecision(3) << winnings << "!" << endl << endl;

  cout << " [1] to bid on items to earn chips" << endl;
  cout << " [2] to play PLINKO!" << endl;
  cout << " [3] to print out the current board" << endl;
  cout << " [Q] to quit" << endl;
  cout << endl;

  cout << "Your choice?: ";
  cin >> userChoice;
  cout << endl;

  //Validating user Choice
  while ((userChoice != '1') && (userChoice != '2') && (userChoice != '3') && (userChoice != 'q') && (userChoice != 'Q')) {
    cout << "You did not enter a valid response!" << endl;
    cout << "Enter another choice?: ";
    cin >> userChoice;
    
  } //while bracket
    
  return userChoice;

  
} //printMenu bracket

//------------------------------------------------------------------------------------------
//generates a random number seed and returns a random number 0-4

int bidOnPrizes(void) { 
  int C; // chips earned 0-4
  srand(time(0));
  C = rand() % 5;
  
  return C;
}   //bidOnPrize bracket

//------------------------------------------------------------------------------------------
//takes in the plinkoBoard and users choice column start location and returns the total earnings from that one round

int playPlinko(char plinkoBoard[12][17], int slot) {
  int puckMove;
  int earnings = 0;

  switch (slot) { //translating user choice with the array location
  case 1:
    puckMove = 0;
    break;
  case 2:
    puckMove = 2;
    break;
  case 3:
    puckMove = 4;
    break;
  case 4:
    puckMove = 6;
    break;
  case 5:
    puckMove = 8;
    break;
  case 6:
    puckMove = 10;
    break;
  case 7:
    puckMove = 12;
    break;
  case 8:
    puckMove = 14;
    break;
  case 9:
    puckMove = 15;
    break;
  }
  

  for (int i = 1; i < 13; i++) {
    if (puckMove == 0) { //Left Wall
      ++puckMove;
      plinkoBoard[i][puckMove] = '*';                                                                                                                  
    }                                                                                                                                                    
    else if (puckMove == 16) {   //Right Wall
      --puckMove;
      plinkoBoard[i][puckMove];
    }
    else {     //Everything in the Middle                                                                                                                
      int dir = puckDirection(i, puckMove);                                                               
      if (dir == 1) {
	++puckMove;
	plinkoBoard[i][puckMove] = '*';                                                                 
      }                                                                                                       
      else if (dir == -1) {
	--puckMove;
	plinkoBoard[i][puckMove] = '*';                                                                                                                
      } 
    } //else brack
  }   //for loop brack    
  

  switch (puckMove) {
  case 0:
    earnings = 50;
    break;
  case 2:
    earnings = 200; 
    break;
  case 4:
    earnings = 500;
    break;
  case 6:
    earnings = 0;
    break;
  case 8:
    earnings = 1000;
    break;
  case 10:
    earnings = 0;
    break;
  case 12:
    earnings = 500;
    break;
  case 14:
    earnings = 200;
    break;
  case 16:
    earnings = 50;
    break;
  }
      
  return earnings; 
  
}   //playPlinko bracket

//------------------------------------------------------------------------------------------
//returns 1 or -1 to make the puck move right or left down the board

int puckDirection (int currentRow, int currentColumn) {
  int R;
  //srand(time(0));
  R = rand();
    
  if ((currentColumn != 0) && (currentColumn != 16)) {    //case not by edge
      if (R % 2 == 0) {        //left or right return values
	return 1;
      } 
      else {
	return -1;
      } 
    } 
  else {                                             //case by edge 
    if (currentColumn == 0) {      //case left wall
      return 1;
    }
    else if (currentColumn == 16) { //case right wall
      return -1;
    }
    else {     //CHECKING FOR ERROR
      cout << "puckDirection Error" << endl; 
    }
  }
  return -1;
}   //puckDirection bracket

//------------------------------------------------------------------------------------------  
//displays the array of characters in an orderly manner

void displayBoard(char plinkoBoard[12][17]) {

  //Laying out the first line in the array
  plinkoBoard[0][0] = '1';
  plinkoBoard[0][2] = '2';
  plinkoBoard[0][4] = '3';
  plinkoBoard[0][6] = '4';
  plinkoBoard[0][8] = '5';
  plinkoBoard[0][10] = '6';
  plinkoBoard[0][12] = '7';
  plinkoBoard[0][14] = '8';
  plinkoBoard[0][16] = '9';
  //------------------------

  
  for (int i = 0; i < 13; i++) {
    for (int e = 0; e < 17; e++) {
      cout << plinkoBoard[i][e];
      cout << "      ";

      if ((i==0) && (e==16)) {
	cout << "       " << endl;         //Fixing display ERROR
      }
      else if (e == 16) {
	cout << endl;
      }
    }
  }
  cout << "$50         $200          $500           $0          $1,000          $0           $500          $200           $50   " << endl; 
  
}   //displayBoard bracket

//------------------------------------------------------------------------------------------
//creates the plinkoBoard array and resets it when called

void resetBoard(char plinkoBoard[12][17]) {       //sets the array back to default values
  
  for (int i = 0; i < 13; i++) {
    for (int e = 0; e < 17; e++) {
      if (i == 0) { //First Row
	if (e % 2 == 0) { //Every other number
	  
	  int n = 0; //n incriments every other column
	  char c = n;//c converts num to char
	  
	  plinkoBoard[i][e] = n;
          ++n;
        }
        else { //Every other space                                                                                                        
          plinkoBoard[i][e] = ' ';
        }
	
      }
      else { //Bottom Rows                                        //May encounter problem with bottom Row here           
        if (i % 2 != 0) { //Every odd Row                                                                               
          if (e % 2 == 0) { //Every even Column
	    
            plinkoBoard[i][e] = '|';
          }
          else { //Every odd Column                                                                                                       
            plinkoBoard[i][e] = ' ';
          }
        }
        else { //Every even Row                                                                
          if (e % 2 == 0) { //Every even Column
	    
            plinkoBoard[i][e] = ' ';
          }
          else { //Every odd Column
	    
            plinkoBoard[i][e] = '|';
          }
        }
      }
      
    } //for #2     
  } //for #1                                                                                                                             
  
}   //resetBoard bracket
