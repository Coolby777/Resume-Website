/*                                                             
  COLBY KOPACZ                                                                
  CPSC 1070                                                            
  12/05/2022                                       PROJECT 4                              
  C82946549                                                                                             
                                                                                                                            
References:                                                                               
  * 2000. Fgets. (2000). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstdio/fgets/?kw=fgets  
  * 2000. Fopen. (2000). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstdio/fopen/?kw=fopen      
  * 2002. Strncat. (2002). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstring/strncat/?kw=strncat  
*/

#include "Wordle.h"
#include <stdio.h>

int main() {
  helpMe();    
}
