Colby Kopacz
C82946549
ckopacz@clemson.edu

References:                                                   
  * 2000. Fgets. (2000). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstdio/fgets/?kw=fgets   
  * 2000. Fopen. (2000). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstdio/fopen/?kw=fopen  
  * 2002. Strncat. (2002). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstring/strncat/?kw=strncat  


Academic Honesty Statement:
I certify that 100% of the work I have submitted is my own and any references that I used were
cited in the head of the file. I did not work with any other students in the process of working
on this project and only used the resources specified in the directions document includeing
questions to TAs Bode and Isaac.
