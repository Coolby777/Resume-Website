/*
  COLBY KOPACZ
  CPSC 1070
  12/05/2022                                       PROJECT 4
  C82946549

  References:
  * 2000. Fgets. (2000). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstdio/fgets/?kw=fgets
  * 2000. Fopen. (2000). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstdio/fopen/?kw=fopen
  * 2002. Strncat. (2002). Retrieved November 25, 2022 from https://cplusplus.com/reference/cstring/strncat/?kw=strncat
*/

#include "Wordle.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <ctype.h>

//-----------------------------------------------
// Reads in the dictionary file
// Returns the number of 5-character words.
int loadDictionary(char *wordPtr[])
{
  int x = 0, y = 0; // counts number of words
  char validWord[50] = "Hello";

  // Open File
  FILE *dFile = fopen("/usr/share/dict/words", "r");

  if (dFile != NULL)
  {
    while (fgets(validWord, 50, dFile) != NULL)
    {

      if (validateWord(validWord) == 1)
      {
        // adding memory for array
        wordPtr[x] = (char *)malloc(sizeof(char) * 10);
        // filling array with valid words
        strcpy(wordPtr[x], validWord);
        ++x;
      }
      ++y;
    }
  }
  else
  {
    puts("Error opening file");
  }

  // Close File
  fclose(dFile);

  // Removing '\n'
  for (int i = 0; i < x; ++i)
  {
    wordPtr[i][5] = '\0';
  }

  printf("%d out of %d words in the dictionary are 5 characters!\n", x, y);

  return x;
}

//-----------------------------------------------
// Prompts the user to enter in the Wordle clue
// Returns the provided characters without spaces.
char *promptUser()
{
  char userWord[50] = {'\0'};
  char a, b, c, d, e;

  puts("\nEnter the Wordle clues using the following scheme:");
  puts("         A-Z for a known letter in the right position");
  puts("         a-z for a letter that is correct in the wrong position");
  puts("         * for unknown letter");
  puts("         Separate each with a space (e.g., T * G i R)");
  printf("Enter your query now: ");
  scanf(" %c %c %c %c %c", &a, &b, &c, &d, &e);

  strncat(userWord, &a, 1);
  strncat(userWord, &b, 1);
  strncat(userWord, &c, 1);
  strncat(userWord, &d, 1);
  strncat(userWord, &e, 1);

  char *finalWord = userWord;

  return finalWord;
}

//-----------------------------------------------
// Processes the word list of size num5 based on
// the 5 characters provided.
void processGuess(char *wordPtr[], int num5, char a, char b, char c, char d, char e)
{
  int numA = 0, numB = 0, numC = 0, numD = 0, numE = 0; // number of words with this letter
  int boolPrint = 1;                                    // becomes 0 if it doesnt need to call print

  for (int i = 0; i < num5; ++i)
  {

    if (toupper(wordPtr[i][0]) == a)
    {
      ++numA;
    }
    if (toupper(wordPtr[i][1]) == b)
    {
      ++numB;
    }
    if (toupper(wordPtr[i][2]) == c)
    {
      ++numC;
    }
    if (toupper(wordPtr[i][3]) == d)
    {
      ++numD;
    }
    if (toupper(wordPtr[i][4]) == e)
    {
      ++numE;
    }
  }

  if (numA > 0)
  {
    printf("Found %d words starting with %c\n", numA, a);
  }
  if (numB > 0)
  {
    printf("Found %d words with %c in position 2\n", numB, b);
  }
  if (numC > 0)
  {
    printf("Found %d words with %c in position 3\n", numC, c);
  }
  if (numD > 0)
  {
    printf("Found %d words with %c in position 4\n", numD, d);
  }
  if (numE > 0)
  {
    printf("Found %d words with %c in position 5\n", numE, e);
  }

  // Creating copy of valid words array
  char *copy[102402];
  for (int i = 0; i < num5; ++i)
  {
    // adding memory for array
    copy[i] = (char *)malloc(sizeof(char) * 10);
    // filling array with valid words
    strcpy(copy[i], wordPtr[i]);
  }

  // Removing '\n'
  for (int i = 0; i < num5; ++i)
  {
    copy[i][5] = '\0';
  }

  // Emptying wordPtr
  for (int i = 0; i < num5; ++i)
  {
    strcpy(wordPtr[i], "");
  }

  char *capitalWords[102402];
  int p = 0; // used for incrimenting
             // p is number of words in capitalWords

  // Collecting all words with specified capital letters
  //---------------------------------------------------

  int numCap = 0; // holds the number of capital letters in user word
  int count = 0;  // counter for capital letters seen
  char userWord[5];
  userWord[0] = a;
  userWord[1] = b;
  userWord[2] = c;
  userWord[3] = d;
  userWord[4] = e;

  // Filling numCap
  for (int i = 0; i < 5; ++i)
  {
    if (isupper(userWord[i]))
    {
      ++numCap;
    }
  }

  if (numCap > 1)
  {

    // cycling through every word taken in
    for (int i = 0; i < num5; ++i)
    { // i represents the word in the array
      count = 0;
      for (int x = 0; x < 5; ++x)
      {
        if ((toupper(copy[i][x]) == userWord[x]) && (isupper(userWord[x])))
        { // if the letter matches and is capital
          ++count;
        }
      }
      if (count == numCap)
      { // if the number of cap matches is equal to the number of Capital letters in user input
        capitalWords[p] = (char *)malloc(sizeof(char) * 10);
        strcpy(capitalWords[p], copy[i]);
        ++p;
      }
    }
  }
  else if (numCap == 1)
  {
    boolPrint = 0;
    printf("There are too many possibilities!\n\n");
  }
  else
  { // case where there are no upper case letters
    for (int i = 0; i < num5; ++i)
    {
      capitalWords[i] = (char *)malloc(sizeof(char) * 10);
      strcpy(capitalWords[i], copy[i]);
    }
    p = num5;
  }
  //------------------------------------------------------------

  // Removing letters that dont fit criteria of lower case letters
  //-------------------------------------------------------------
  int numLow = 0;                             // holds the number of lower case letters
  int k1 = 0, k2 = 0, k3 = 0, k4 = 0, k5 = 0; // incriment variables

  char *temp1[102402];
  char *temp2[102402];
  char *temp3[102402];
  char *temp4[102402];

  // Filling numLow
  for (int i = 0; i < 5; ++i)
  {
    if (islower(userWord[i]))
    {
      ++numLow;
    }
  }

  if (numLow > 0)
  {
    //----------------------------------------------------------------
    // This code is meant to check if the letter is lower case.
    // If it is then it will add the words that have that letter
    // but not in the location it was in. These all valid words will be
    // passed to another array that checks until all 5 letters
    // have been checked.
    //----------------------------------------------------------------
    if (islower(userWord[0]))
    { // if the letter in location 0 is lowercase
      for (int i = 0; i < p; ++i)
      {
        for (int x = 0; x < 5; ++x)
        {
          if ((capitalWords[i][x] == userWord[0]) && (x != 0))
          { // if the letter is anywhere but the location it was
            temp1[k1] = (char *)malloc(sizeof(char) * 10);
            strcpy(temp1[k1], capitalWords[i]);
            ++k1;
          }
        }
      }
    }
    else
    { // if letter isnt lowercase we pass the contents to the next array
      for (int i = 0; i < p; ++i)
      {
        temp1[i] = (char *)malloc(sizeof(char) * 10);
        strcpy(temp1[i], capitalWords[i]);
        k1 = p; // passing down the size of the array
      }
    }

    if (islower(userWord[1]))
    { // if location  is lower case
      for (int i = 0; i < k1; ++i)
      {
        for (int x = 0; x < 5; ++x)
        {
          if ((temp1[i][x] == userWord[1]) && (x != 1))
          { // if the letter is anywhere but the location it was
            temp2[k2] = (char *)malloc(sizeof(char) * 10);
            strcpy(temp2[k2], temp1[i]);
            ++k2;
          }
        }
      }
    }
    else
    { // if letter isnt lowercase we pass the contents to the next array
      for (int i = 0; i < k1; ++i)
      {
        temp2[i] = (char *)malloc(sizeof(char) * 10);
        strcpy(temp2[i], temp1[i]);
        k2 = k1; // passing down the size of the array
      }
    }

    if (islower(userWord[2]))
    { // if location 2 is lower case
      for (int i = 0; i < k2; ++i)
      {
        for (int x = 0; x < 5; ++x)
        {
          if ((temp2[i][x] == userWord[2]) && (x != 2))
          { // if the letter is anywhere but the location it was
            temp3[k3] = (char *)malloc(sizeof(char) * 10);
            strcpy(temp3[k3], temp2[i]);
            ++k3;
          }
        }
      }
    }
    else
    { // if letter isnt lowercase we pass the contents to the next array
      for (int i = 0; i < k2; ++i)
      {
        temp3[i] = (char *)malloc(sizeof(char) * 10);
        strcpy(temp3[i], temp2[i]);
        k3 = k2; // passing down the size of the array
      }
    }

    if (islower(userWord[3]))
    { // if location 3 is lower case
      for (int i = 0; i < k3; ++i)
      {
        for (int x = 0; x < 5; ++x)
        {
          if ((temp3[i][x] == userWord[3]) && (x != 3))
          { // if the letter is anywhere but the location it was
            temp4[k4] = (char *)malloc(sizeof(char) * 10);
            strcpy(temp4[k4], temp3[i]);
            ++k4;
          }
        }
      }
    }
    else
    { // if letter isnt lowercase we pass the contents to the next array
      for (int i = 0; i < k3; ++i)
      {
        temp4[i] = (char *)malloc(sizeof(char) * 10);
        strcpy(temp4[i], temp3[i]);
        k4 = k3; // passing down the size of the array
      }
    }

    if (islower(userWord[4]))
    { // if location 4 is lower case
      for (int i = 0; i < k4; ++i)
      {
        for (int x = 0; x < 5; ++x)
        {
          if ((temp4[i][x] == userWord[4]) && (x != 4))
          {                                // if the letter is anywhere but the location it was
            strcpy(wordPtr[k5], temp4[i]); //
            ++k5;
          }
        }
      }
    }
    else
    { // if letter isnt lowercase we pass the contents to the next array
      for (int i = 0; i < k4; ++i)
      {
        strcpy(wordPtr[i], temp4[i]);
        k5 = k4; // passing down the size of the array
      }
    }
  }

  else
  { // if there are no lower case then we just fill the array with the capital letters
    for (int i = 0; i < p; ++i)
    {
      if (islower(capitalWords[i][0]))
      {
        strcpy(wordPtr[k1], capitalWords[i]);
        ++k1;
      }
    }
  }
  //-------------------------------------------------------------

  if (boolPrint == 1)
  {
    printResults(wordPtr, num5);
  }
}

//-----------------------------------------------
// Prints out the list of viable words without
// duplicates only if there is more than one known letter.
void printResults(char *wordPtr[], int num5)
{
  int a = 0;

  puts("Viable Options:");

  while ((a < num5) && (strcmp(wordPtr[a], "")))
  {
    printf("        %d: %s\n", a, wordPtr[a]);
    ++a;
  }

  puts("");
}

//-----------------------------------------------
// Starts the process of the Wordle assistant.
void helpMe()
{
  char *wordPtr[102402];
  int num5; // number of 5 letter words
  char a, b, c, d, e;

  puts("\nWelcome to the Wordle Assistant! ");
  puts("Processing Dictionary");
  num5 = loadDictionary(wordPtr);
  char *userLetters = promptUser();

  a = *userLetters++;
  b = *userLetters++;
  c = *userLetters++;
  d = *userLetters++;
  e = *userLetters;

  processGuess(wordPtr, num5, a, b, c, d, e);
  // printResults(wordPtr, num5);
}

//-----------------------------------------------
// Validates the potential words
// Returns 1 if valid, 0 if not
int validateWord(char w[])
{
  int valid = 1;

  if (w[6] != '\0')
  {
    valid = 0;
  }

  for (int i = 0; i < 5; ++i)
  {
    if ((isalpha(w[i])) == 0)
    {
      valid = 0;
    }
  }

  return valid;
}
