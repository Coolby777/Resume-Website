/*                                                                                                                
  COLBY KOPACZ                                                                                                    
  CPSC 1070                                                                                                       
  11/11/2022                                       PROJECT 3                                                      
  C82946549   
  
  References
* Lecture Slides #28
* Book 19.5 Dynamic Queues (pg 1204 - 1207)
*/
#include <iostream>
#include <string>
#include "Queue.h"
#include "Cipher.h"

using namespace std;

int main(){
    string codedMessage;
    string message;
    
    //Class Objects
    Queue Q_obj;
    Cipher C_obj;
    
    
    
    //Testing Queue
    /*-----------//
    for (int k = 1; k <= 5; k++) {
        Q_obj.enqueue(k);
    }
    
    while (!Q_obj.isEmpty()) {
        int val;
        Q_obj.dequeue(val);
        cout << val << "  ";
    }
    cout << endl;
    //----------*/
    
    
    //Checking Encoding Functions
    cout << "Key: [1, 2, 3, 4]" << endl;
    cout << "Encoding: ";
    getline(cin, message);
    cout << "Encoded: " << C_obj.encodeMessage(message) << endl << endl;
    
    //Checking Decoding Functions
    cout << "Key: [1, 2, 3, 4]" << endl;
    cout << "Decoding: ";
    cin >> codedMessage;
    cout << "Decoded: " << C_obj.decodeMessage(codedMessage) << endl << endl;
    
}
