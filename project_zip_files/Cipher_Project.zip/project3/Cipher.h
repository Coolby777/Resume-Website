/*                                                                                                                
  COLBY KOPACZ                                                                                                    
  CPSC 1070                                                                                                       
  11/11/2022                                       PROJECT 3                                                      
  C82946549                                                                                                       
*/
#ifndef CIPHER_H
#define CIPHER_H
#include <string>
#include "Queue.h"

using namespace std;

class Cipher {
    
    private:
        int keySize;
        int defaultKey[4] {1,2,3,4};
        char alphabet[26] {'a','b','c','d','e','f','g','h','i','j','k',
                            'l','m','n','o','p','q','r','s','t','u','v',
                            'w','x','y','z'};
        int* listPtr; //cycles through the key
        string code = "";
        string myMessage = "";
        Queue q; //Queue object
    
    public:
        Cipher();
        void setCipher(int, int[]);
        int* getCipher();
        string encodeMessage(string in);
        string decodeMessage(string in);
    
};

#endif
