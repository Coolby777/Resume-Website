/*                                                                                                                
  COLBY KOPACZ                                                                                                    
  CPSC 1070                                                                                                       
  11/11/2022                                       PROJECT 3                                                      
  C82946549  
  
  References
* Lecture Slides #28
* Book 19.5 Dynamic Queues (pg 1204 - 1207)
*/
#ifndef QUEUE_H
#define QUEUE_H
#include <memory>

using namespace std;

class Queue {
    private:
        struct Node {
            int num;
            Node *next;
            Node(int num1, Node *next1 = nullptr) {
                num = num1;
                next = next1;
            }
        };
        
        Node *rear;
        Node *front;
        int count = 0;
        int max = 100;
    
    public:
        void enqueue(int x); 
        void dequeue(int &x); 
        bool isEmpty(); 
        bool isFull();
        Queue();   
        ~Queue();
    
};

#endif
