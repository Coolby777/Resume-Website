/*                                                                                                                
  COLBY KOPACZ                                                                                                    
  CPSC 1070                                                                                                       
  11/11/2022                                       PROJECT 3                                                      
  C82946549                                                                                                       
*/
#include <iostream>
#include <string>
#include "Cipher.h"
#include "Queue.h"

using namespace std;

//sets to a repeating key of 1, 2, 3, 4
Cipher::Cipher() { 
    listPtr = defaultKey;
    setCipher(4, defaultKey);
}

//takes in and stores the repeating key 
void Cipher::setCipher(int listSize, int list[]) {
    keySize = listSize;
    listPtr = list;
}

//returns a pointer that points to the list
int* Cipher::getCipher() {
    return listPtr;
}

//sends in a string to encode and returns an encoded string
string Cipher::encodeMessage(string userString) {
    int stringLength = userString.length();
    int val;
    
    
    //Removing unecessary characters and cases
    //---------
    for (int i = 0; i < stringLength; ++i ) {
        if (isalpha(userString.at(i))) {
            code += tolower(userString.at(i));
        }
    }
    stringLength = code.length();
    //---------
    
    //Encoding
    //----------
    Queue key1;           //Queue object
    bool coded = false;  //breaks the while loop
    int k = 0;           //incriments in while loop
    string newCode;
    int* copyPtr = listPtr;

    while (coded == false) {
        
        //Refilling the Queue
        if ((k % keySize) == 0) { 
            copyPtr = listPtr;
            for (int i = 0; i < keySize; ++i) {
                key1.enqueue(*copyPtr++);
            }   
        }
        
        //Returning next val
        key1.dequeue(val);
        
        
        //Adjusting character in string
        for (int i = 0; i < 26; ++i) {
            if (code.at(k) == alphabet[i]) {
                if (val < 0) { 
                    newCode += alphabet[(i + (26 + (val % 26))) % 26];
                }
                else {
                    newCode += alphabet[(i + (val % 26)) % 26];
                }
            }
        }
        
        
        //Checking if loop should end
        if (k++ == (stringLength - 1)) {
            while(!key1.isEmpty()) {
                key1.dequeue(val);
            }
            
            coded = true;
        }
        
    }
    //----------    
    return newCode;
}

//sends in an encoded string and returns a decoded string
string Cipher::decodeMessage(string userString) {
    int stringLength = userString.length();
    int val;
    code = "";
    
    //Removing unecessary characters and cases
    //---------
    for (int i = 0; i < stringLength; ++i ) {
        if (isalpha(userString.at(i))) {
            code += tolower(userString.at(i));
        }
    }
    stringLength = code.length();
    //---------
    
    //Decoding
    //----------
    Queue key2;           //Queue object
    bool coded = false;  //breaks the while loop
    int k = 0;           //incriments in while loop
    string newCode;
    int* copyPtr = listPtr;

    while (coded == false) {
        
        //Refilling the Queue
        if ((k % keySize) == 0) { 
            copyPtr = listPtr;
            for (int i = 0; i < keySize; ++i) {
                key2.enqueue(*copyPtr++);
            }   
        }
        
        //Returning next val
        key2.dequeue(val);
        
        
        //Adjusting character in string
        for (int i = 0; i < 26; ++i) {
            if (code.at(k) == alphabet[i]) {
                if (((i - (val % 26)) % 26) < 0) { 
                    newCode += alphabet[26 + ((i - (val % 26)) % 26)];
                }
                else {
                    newCode += alphabet[(i - (val % 26)) % 26];
                }
            }
        }
        
        
        //Checking if loop should end
        if (k++ == (stringLength - 1)) {
            while(!key2.isEmpty()) {
                key2.dequeue(val);
            }
            
            coded = true;
        }
        
    }
    //----------
    
    return newCode;
}
