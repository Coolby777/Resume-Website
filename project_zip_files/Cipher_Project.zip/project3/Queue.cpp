/*                                                                                                                
  COLBY KOPACZ                                                                                                    
  CPSC 1070                                                                                                       
  11/11/2022                                       PROJECT 3                                                      
  C82946549   
  
  References
* Lecture Slides #28
* Book 19.5 Dynamic Queues (pg 1204 - 1207)
*/
#include <iostream>
#include <memory>
#include "Queue.h"

using namespace std;

//Constructor 
Queue::Queue() {
    front = nullptr;
    rear = nullptr;
}

//Destructor
Queue::~Queue() {
    Node *trash = front;
    while (trash != nullptr)
    {
       front = front->next;
       trash->next = nullptr;
       delete trash;
       trash = front;
    }
}

//Adds the element at the end of the linked list
void Queue::enqueue(int x) {
    if(!isFull())   {  
        if (isEmpty()) {
            front = new Node(x);
            rear = front;
        }
        else {
            rear->next = new Node(x);
            rear = rear->next;
        }
        ++count;
    }
    else {
        cout << "List is FULL" << endl;
    }
}

//Removes the element at the end of the linked list
void Queue::dequeue(int &x) {
    Node *temp = nullptr;
    
    if(!isEmpty())    {
        x = front->num;
        temp = front;
        front = front->next;
        delete temp;
        --count;
    }
    else {
        cout << "List is EMPTY" << endl;
    }
}

//Returns true if the list is empty
bool Queue::isEmpty() {
    return (front == nullptr); //later set to nullptr
}

//Returns true if the list is full.
bool Queue::isFull() {
    
    return (count == max);
}
